package com.java.assignment120923;

import java.util.Date;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class PredefinedFI {
	
	public static void main(String[] args) {
		
		//Part 3: Using Pre-defined Functional Interfaces
		/*1.	Predicates:
		 * 
�	Write a predicate that checks if a number is even.*/

		Predicate<Integer> p=i->i%2==0;
		
		System.out.println(p.test(4));
		System.out.println(p.test(5));
		
		//�	Write a predicate that checks if a string's length is greater than 5.
		
		Predicate<String> p1=i->i.length()>5;
		
		System.out.println(p1.test("Technology"));
		
		//2.	Function Interface:
		
		//�	Write a function that takes a string and returns its length.
		
		Function<String,Integer> f=s->s.length();//String is input   Integer is return type
		System.out.println(f.apply("Techsolution"));
		
		//�	Write a function that takes a string and returns its lowercase version.
		Function<String,String> f1=s->s.toLowerCase();//String is input   Integer is return type
		System.out.println(f1.apply("Techsolution"));
		
		
		//3.	Consumer and Supplier:
		/*Write a consumer that prints the string it receives.*/

		Consumer<String> c=s->System.out.println(s);
		c.accept("Techology");
		
		//�	Write a supplier that returns the current date-time as a formatted string.
		Supplier<Date> s=()->new Date();
		System.out.println(s.get());
	}

}
