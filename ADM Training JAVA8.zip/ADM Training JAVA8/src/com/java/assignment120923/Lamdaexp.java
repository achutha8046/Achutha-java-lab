/*1.	Basic Lambda Expressions:
�	Write a lambda expression that takes two integers and returns their sum.
�	Write a lambda expression that takes a string and returns its uppercase version.

*/
package com.java.assignment120923;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

interface Sum{
	int add(int x,int y);
}

interface Uppercase{
	
	void display(String str);
}

public class Lamdaexp {
	
	public static void main(String[] args) {
		
		//Part 1: Lambda Expressions
		
		//1a.Write a lambda expression that takes two integers and returns their sum.
		Sum s1=(x,y)->(x+y);
		
		System.out.println(s1.add(100,400));
		
		//1b.Write a lambda expression that takes a string and returns its uppercase version.
		
		Uppercase uc=(str)->System.out.println(str.toUpperCase());
		
		uc.display("arunkumar");
		
		/*2.	Comparator Using Lambda:
		�	Given a list of strings, sort them based on their length using a lambda expression.*/
		List<String> list = Arrays.asList("mango","apple","bananna","orange","guava");
		
		System.out.println(list);
		System.out.println("----------------");
		Collections.sort(list,(obj1,obj2)->obj1.compareTo(obj2));
		
		System.out.println(list);
		
		/*3.	Runnable Using Lambda:
�	Create a new thread using the Runnable interface and lambda expressions. The thread should print "Lambda Runnable in action!" when run.*/
		
		
		Runnable r=()->System.out.println("Lambda Runnable in action!");
		Thread t1=new Thread(r);
		
		
		t1.start();
	
	}

}



