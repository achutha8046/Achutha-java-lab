package com.java.assignment120923;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FunctionalProgramming {
	
	public static void main(String[] args) {
	//Part 2: Functional Programming
		
		/*1.	Streams:
			�	Convert a list of integers into a stream, filter out the odd numbers, and collect the result into a new list.*/

	
	List<Integer> list = Arrays.asList(2,3,4,5,6,7,8,9);
	
	
	list.stream().forEach(System.out::println);
	System.out.println("-------------------");
	
	List<Integer> oddnums=list.stream().filter(i->(i%2)!=0).collect(Collectors.toList());
	
	System.out.println("odd numbers"+oddnums);
	
	/*2b.	Map-Filter-Reduce:
	�	Using a list of strings, convert all strings to uppercase (map), filter out strings that are less than 4 characters long, and concatenate the remaining strings (reduce).*/

	
	List<String> list1 = Arrays.asList("mango","apple","bananna","orange","guava");
	
	List<String> uppercase=list1.stream().map(String::toUpperCase)
		      .collect(Collectors.toList());
	
	System.out.println(uppercase);
	
	}
	
}
